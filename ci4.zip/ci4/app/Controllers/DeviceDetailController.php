<?php

namespace App\Controllers;

class DeviceDetailController extends BaseController
{
    public function deviceDetail()
    {
        $data =[
                [
                    'id' => 430,
                    'device_image' => '/images/gambar1.jpg',
                    'device_name' => 'Jakarta One Card',
                    'device_brand' => 'interplan',
                    'device_quantity' => 23,
                    'device_boolean' => 'ON'
                ],
                [   
                    'id' => 266,
                    'device_image' => '/images/gambar2.jpeg',
                    'device_name' => 'Sambungan Listrik Pintar',
                    'device_brand' => 'infinium',
                    'device_quantity' => 68,
                    'device_boolean' => 'OFF'
                ],
                [
                    'id' => 637,
                    'device_image' => '/images/gambar3.jpeg',
                    'device_name' => 'Penyiram otomatis',
                    'device_brand' => 'dotsense',
                    'device_quantity' => 35,
                    'device_boolean' => 'ON'
                ]
                ]; 
                $detail = [];
                foreach ($data as $d) {
                    if ($d['id']==$_GET['id'])
                    {
                        $detail=[
                            'title' => 'Devices | Monitoring IoT',
                            'data' => $d
                        ];
                    }
                }
        return view('pages/deviceDetail', $detail);
    }
}