<?php

namespace App\Controllers;

class HomeController extends BaseController
{
    public function index()
    {
        $data =[
            'title' => 'Home | Monitoring IoT'
        ];
        
        return view('pages/home', $data);
    }
}