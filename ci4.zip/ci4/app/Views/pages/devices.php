<?= $this->extend('layout/template'); ?>
<?= $this->section('content'); ?>

<div class="container">
    <div class="row">
        <div class="col">
            <h1 class="mt-2">Daftar Barang</h1>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col" style="width: 20%;">Gambar</th>
                        <th scope="col">Device Name</th>
                        <th scope="col">Merk</th>
                        <th scope="col">Jumlah</th>
                        <th scope="col">Status</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $num = 1; foreach ($barang as $b) : ?>
                        <tr>
                            <th scope="row"><?= $num++ ?></th>
                            <td><img src="<?= $b['device_image']; ?>" alt="#" class="w-100"></td>
                            <td><?= $b['device_name']; ?></td>
                            <td><?= $b['device_brand']; ?></td>
                            <td><?= $b['device_quantity']; ?></td>
                            <td><?= $b['device_boolean']; ?></td>
                            <td><a href="/pages/deviceDetail/?id=<?= $b['id']; ?>">Deskripsi</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <?= $this->endSection(); ?>