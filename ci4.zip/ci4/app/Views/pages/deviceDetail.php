<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1>Detail Produk</h1>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col" style="width: 20%;">Gambar</th>
                        <th scope="col">Device Name</th>
                        <th scope="col">Merk</th>
                        <th scope="col">Jumlah</th>
                        <th scope="col">Status</th>
                    </tr>
                </thead>
                <tbody>
                        <tr>
                            <td><img src="<?= $data['device_image']; ?>" alt="#" class="w-100"></td>
                            <td><?= $data['device_name']; ?></td>
                            <td><?= $data['device_brand']; ?></td>
                            <td><?= $data['device_quantity']; ?></td>
                            <td><?= $data['device_boolean']; ?></td>
                        </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>