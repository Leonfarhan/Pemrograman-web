<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <br>
            <h1>Selamat datang ditoko farhan's store</h1>
            <p>
                Tempat yang cocok membeli barang terkait dengan Monitoring IoT.
            </p>
            <img src="/images/iot.png" class="mx-auto d-block">
        </div>
    </div>



    <?= $this->endSection(); ?>